package com.tata.dao;

import com.tata.models.Admin;
import com.tata.models.Customer;

import java.sql.SQLException;
import java.util.List;

public interface AdminDao {
    void addAdmin(Admin admin) throws SQLException;
    void updateAdmin(int a_id,String a_name);
    void deleteAdmin(int a_id);
    Admin getAdminbyId(int aid) throws SQLException;

    public List<Customer> getallcustomer() throws SQLException;

}
