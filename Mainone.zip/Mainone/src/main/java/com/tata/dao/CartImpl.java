package com.tata.dao;

import com.tata.models.Cart;
import com.tata.models.Customer;
import com.tata.models.Product;
import helper.connections;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CartImpl implements CartDao{
    private Connection conn;
    private ResourceBundle resourceBundle;
    private PreparedStatement ap,dp,upc,gP;
    private ResultSet resultSet;
    public CartImpl(){
        conn= connections.getConnection();
        if(conn!=null)
        {
            System.out.println("Connections Established...");
        }
        else{
            System.out.println("Connection Error");
        }
        resourceBundle= ResourceBundle.getBundle("db");
    }

    @Override
    public void addProduct(Customer customer, Product product, int qty) throws SQLException {
        String ap1=resourceBundle.getString("app1");
        ap=conn.prepareStatement(ap1);
        ap.setLong(1,customer.getCcid_ref());

        ap.setString(2, product.getPname());
        ap.setString(4, product.getPname());
        ap.setFloat(3,10000);
        ap.setInt(4,qty);
        ap.setInt(5,customer.getCid());
        ap.setInt(6,product.getPid());
        ap.executeUpdate();



    }

    @Override
    public void deleteProduct(int p_id) throws SQLException {
        String query = resourceBundle.getString("deleteP");
        dp = conn.prepareStatement(query);
        dp.setInt(1,p_id);
        dp.executeUpdate();

    }

    @Override
    public void updateQuantity(Customer customer, int productId, int Quantity) throws SQLException {
        int cartId= customer.getCcid_ref();
        String updateP=resourceBundle.getString("updatePinC");
        upc=conn.prepareStatement(updateP);
        upc.setInt(1,10);
        upc.setInt(2,cartId);
        upc.setInt(3,productId);
        upc.executeUpdate();


    }

    @Override
    public List<Cart> getAllProducts(Customer customer) throws SQLException {
        int cartId  = customer.getCcid_ref();
        List<Cart>cartItemsList=new ArrayList<>();
        Product product=null;
        Cart cartItems=null;
        ProductDao productDao=new ProductImpl();
        String getAllP=resourceBundle.getString("getAllPinC");
        gP=conn.prepareStatement(getAllP);
        gP.setInt(1,cartId);
        resultSet=gP.executeQuery();
        while (resultSet.next())
        {
            //product=productDao.getProductById(resultSet.getInt(2));
//            System.out.println(product.getPid()
//                    +" "+product.getPname()
//                    +" "+product.getPrice()
//                    +" "+product.getCategory().getCname()
//                    +" "+resultSet.getDate(3)
//                    +" "+resultSet.getInt(4));
            cartItems=new Cart();
            cartItems.setQty(resultSet.getInt(4));
            cartItems.setPname(resultSet.getString(2));
            cartItems.setPrice(resultSet.getInt(3));
            cartItems.setP_id_ref(resultSet.getInt(6));
            cartItems.setC_id_ref(resultSet.getInt(5));
            cartItems.setCcid(resultSet.getInt(1));
            //cartItems.setProduct(product);
            //cartItems.setCart(user.getCart());
            cartItemsList.add(cartItems);
        }
        return cartItemsList;

    }
}
