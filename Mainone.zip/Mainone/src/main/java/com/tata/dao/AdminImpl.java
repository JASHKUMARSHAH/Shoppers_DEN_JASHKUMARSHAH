package com.tata.dao;

import com.tata.models.Admin;
import com.tata.models.Customer;
import helper.connections;

import javax.swing.plaf.nimbus.State;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class AdminImpl implements AdminDao {
    private Connection conn;
    private ResourceBundle resourceBundle;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement ada, up, de, gc, pp, gac1,aaaa;

    public AdminImpl() {
        conn = connections.getConnection();
        if (conn != null) {
            System.out.println("Connections Established...");
        } else {
            System.out.println("Connection Error");
        }
        resourceBundle = ResourceBundle.getBundle("db");
    }

    @Override
    public void addAdmin(Admin admin) throws SQLException {
        String adda1 = resourceBundle.getString("adda");
        try {
            ada = conn.prepareStatement(adda1);
            ada.setInt(1, admin.getA_id());
            ada.setString(2, admin.getA_name());
            ada.setString(3, admin.getA_pwd());
            ada.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }


    }

    @Override
    public void updateAdmin(int a_id, String a_name) {
        String upa = resourceBundle.getString("upaa");
        try {
            up = conn.prepareStatement(upa);
            up.setInt(1, a_id);
            up.setString(2, a_name);
            up.executeUpdate();


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void deleteAdmin(int a_id) {
        String dea = resourceBundle.getString("deaa");
        try {
            de = conn.prepareStatement(dea);
            de.setInt(1, a_id);
            de.executeUpdate();


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public Admin getAdminbyId(int aid) throws SQLException {
        Admin admin=new Admin();
        String aa=resourceBundle.getString("aaa");
        aaaa=conn.prepareStatement(aa);
        aaaa.setInt(1,aid);
//        aaaa.setString(2, admin.getA_name());
//        aaaa.setString(3, admin.getA_pwd());
        resultSet= aaaa.executeQuery();
        while(resultSet.next()){
            admin.setA_name(resultSet.getString(2));

        }
        return admin;

    }


    @Override
    public List<Customer> getallcustomer() throws SQLException {
        String gac = resourceBundle.getString("gacc");
        List<Customer> customerList = new ArrayList<Customer>();
        gac1 = conn.prepareStatement(gac);

        resultSet = gac1.executeQuery();
        while (resultSet.next()) {
            Customer customer = new Customer();
            customer.setAddress(resultSet.getString(1));
            customer.setEmail(resultSet.getString(2));
            customer.setName(resultSet.getString(3));
            customer.setPhn(resultSet.getInt(4));
            customer.setPwd(resultSet.getString(5));
            customer.setSec_ans(resultSet.getString(6));
            customer.setSec_q(resultSet.getString(7));
            customer.setCid(resultSet.getInt(8));
            customer.setCcid_ref(resultSet.getInt(9));
            customerList.add(customer);


        }
        return customerList;

    }
}

