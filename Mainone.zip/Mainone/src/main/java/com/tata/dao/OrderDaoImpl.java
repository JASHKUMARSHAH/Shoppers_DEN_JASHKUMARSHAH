package com.tata.dao;
//import com.tata.helper.connections;
import com.tata.models.*;
import com.tata.dao.*;
import com.tata.models.*;
import helper.connections;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class OrderDaoImpl implements OrderDao {

    private Connection conn;
    private PreparedStatement ao,co,dc,goi,vop,cao,aoi,gois;
    private Statement statement;
    private ResultSet resultSet,resultSet2;
    private ResourceBundle resourceBundle;

    public OrderDaoImpl()
    {
        conn= connections.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void placeOrder(Customer customer, Order1 order) throws SQLException {
        int cartId = customer.getCcid_ref();
        CartDao cartDao=new CartImpl();
        List<Cart> cart=cartDao.getAllProducts(customer);
        int totalAmount=0;
        for(Cart cartItems : cart)
        {
            totalAmount+=cartItems.getQty()*cartItems.getPrice();
        }
        String addorder=resourceBundle.getString("addOrder");
        ao=conn.prepareStatement(addorder);
        ao.setInt(1,order.getOrderId());
        if(order.getPaymentMode().equals(PaymentMode.CARD))
        {ao.setString(2,"CARD");}
        else if(order.getPaymentMode().equals(PaymentMode.NETBANKING))
        {
            ao.setString(2,"NETBANKING");
        }
        else
        {
            ao.setString(2,"UPI");
        }
        ao.setDate(3, Date.valueOf(LocalDate.now()));
        ao.setInt(4,cartId);
        ao.setInt(5,order.getStatus());
        ao.setLong(6,totalAmount);
        ao.setInt(7,customer.getCid());

        ao.executeUpdate();
    }

    @Override
    public void confirmOrder(Customer customer, int order_id) throws SQLException {
        String confirmorder = resourceBundle.getString("confirmorder");
        co = conn.prepareStatement(confirmorder);
        co.setInt(1, order_id);
        co.executeUpdate();

        String query2 = resourceBundle.getString("addinOI");
        CartDao cartDao=new CartImpl();
        List<Cart> cartItemsList1=cartDao.getAllProducts(customer);
        for(Cart cartItems : cartItemsList1)
        {
            aoi=conn.prepareStatement(query2);
            aoi.setInt(1,order_id);
            aoi.setInt(2,cartItems.getP_id_ref());
           // aoi.setInt(3,cartItems.getQty());
            aoi.executeUpdate();
        }

        String query = resourceBundle.getString("deleteCart");
        dc=conn.prepareStatement(query);
        dc.setInt(1,customer.getCcid_ref());
        dc.executeUpdate();


    }

    @Override
    public void cancelOrder(int order_id) throws SQLException {
        String query = resourceBundle.getString("cancelOrder");
        cao = conn.prepareStatement(query);
        cao.setInt(1,order_id);
        cao.executeUpdate();
    }

    @Override
    public List<Order1> viewAllOrder(Customer customer) throws SQLException {
        String query = resourceBundle.getString("viewallorder");
        List<Order1>orderList=new ArrayList<Order1>();
        Order1 order=null;
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query + customer.getCid());
        while(resultSet.next())
        {
            order=new Order1();
            order.setOrderId(resultSet.getInt(1));
            if(resultSet.getString(2).equals(PaymentMode.CARD))
            {
                order.setPaymentMode(PaymentMode.CARD);
            }
            else if(resultSet.getString(2).equals(PaymentMode.NETBANKING))
            {
                order.setPaymentMode(PaymentMode.NETBANKING);
            }
            else
            {
                order.setPaymentMode(PaymentMode.UPI);
            }
            order.setOrderDate(resultSet.getDate(3).toLocalDate());
           // order.setCart(user.getCart());
            order.setTotalPayment(resultSet.getLong(6));
            order.setStatus(resultSet.getInt(5));
            order.setCustomer(customer);
            orderList.add(order);
        }
        return orderList;
    }

    @Override
    public Order1 getOrderById(Customer customer,int orderId) throws SQLException {
        String query = resourceBundle.getString("getorderById");
        Order1 order=new Order1();
        goi = conn.prepareStatement(query);
        goi.setInt(1,orderId);
        resultSet = goi.executeQuery();
        while(resultSet.next())
        {
            order.setOrderId(resultSet.getInt(1));
            if(resultSet.getString(2).equals(PaymentMode.CARD))
            {
                order.setPaymentMode(PaymentMode.CARD);
            }
            order.setOrderDate(resultSet.getDate(3).toLocalDate());

            order.setStatus(resultSet.getInt(5));
            order.setTotalPayment(resultSet.getLong(6));
            order.setCustomer(customer);
        }
        return order;
    }


}
