package com.tata.dao;

import com.tata.models.Customer;
import helper.connections;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CustomerImpl implements CustomerDao{
    private Connection conn;
    private ResourceBundle resourceBundle;
    private PreparedStatement ad,up,pp,du;
    private ResultSet resultSet;
   public CustomerImpl(){
       conn= connections.getConnection();
       if(conn!=null)
       {
           System.out.println("Connection Established...");
       }
       else
       {
           System.out.println("Connection has issue...");
       }
       resourceBundle = ResourceBundle.getBundle("db");
       }


    @Override
    public void addCustomer(Customer customer) throws SQLException {
       String query=resourceBundle.getString("addc");

       ad=conn.prepareStatement(query);
       ad.setString(1,customer.getAddress());
       ad.setString(2, customer.getEmail());
       ad.setString(3, customer.getName());
       ad.setInt(4,customer.getPhn());
       ad.setString(5, customer.getPwd());
       ad.setString(6, customer.getSec_ans());
       ad.setString(7, customer.getSec_q());
       ad.setInt(8,customer.getCid());
       ad.setInt(9,customer.getCcid_ref());

       ad.executeUpdate();

    }

    @Override
    public void UpdateCustomer(int cid, String name) throws SQLException {
       String ucc=resourceBundle.getString("uccc");
       up=conn.prepareStatement("ucc");
       up.setInt(8,cid);
       up.setString(3,name);
       up.executeUpdate();


    }
    @Override
    public Customer getcustomerbyid(int cid) throws SQLException {
        Customer customer = new Customer();
        String query = resourceBundle.getString("selectUser1");
        pp=conn.prepareStatement(query);
        pp.setInt(1,cid);
        resultSet= pp.executeQuery();
        while(resultSet.next()) {
            customer.setPwd(resultSet.getString(5));
            customer.setName(resultSet.getString(3));
            customer.setEmail(resultSet.getString(2));
            customer.setPhn(resultSet.getInt(4));
            customer.setAddress(resultSet.getString(1));
            customer.setSec_ans(resultSet.getString(6));
            customer.setSec_q(resultSet.getString(7));
            customer.setCid(resultSet.getInt(8));
            customer.setCcid_ref(resultSet.getInt(9));

//            String query2 = resourceBundle.getString("getcbyuid");
//            pci=conn.prepareStatement(query2);
//            pci.setInt(1,resultSet.getInt(8));
//            Cart cart = new Cart();
//            resultSet2=pci.executeQuery();
//            while (resultSet2.next())
//            {
//                cart.setCartId(resultSet2.getInt(1));
//                cart.setUser(user);
//            }
//            user.setCart(cart);
        }
        return customer;
    }

    @Override
    public void deleteCustomer(int cid) throws SQLException {
        String query = resourceBundle.getString("deleteuser");
        du = conn.prepareStatement(query);
        du.setInt(1,cid);
        du.executeUpdate();

    }
}
