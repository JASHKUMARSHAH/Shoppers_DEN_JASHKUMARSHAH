package com.tata.dao;

import helper.connections;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class LoginImpl implements LoginDao{
    private Connection conn;
    private PreparedStatement cc;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;

    public LoginImpl()
    {
        conn= connections.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }
    @Override
    public boolean check(int Id, String pass) throws SQLException {
        String query = resourceBundle.getString("logincheck");
        boolean check=false;
        String check1=null;
        cc = conn.prepareStatement(query);
        cc.setInt(1,Id);
        resultSet=cc.executeQuery();
//        if(resultSet==null)
//        {
//
//        }
        while(resultSet.next())
        {
            String pwd=resultSet.getString(1);
            if(pass.equals(pwd))
                check=true;
        }
        return check;
    }
}
