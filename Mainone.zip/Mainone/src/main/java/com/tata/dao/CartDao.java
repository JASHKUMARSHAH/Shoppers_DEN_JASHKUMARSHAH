package com.tata.dao;

import com.tata.models.Cart;
import com.tata.models.Customer;
import com.tata.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface CartDao {
    public void addProduct(Customer customer, Product product, int qty) throws SQLException;
    public void deleteProduct(int p_id) throws SQLException;
    public void updateQuantity(Customer customer, int productId, int Quantity) throws SQLException;
    public List<Cart> getAllProducts(Customer customer) throws SQLException;
}
