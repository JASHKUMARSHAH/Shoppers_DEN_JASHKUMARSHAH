package com.tata.dao;

import com.tata.models.Customer;

import java.sql.SQLException;

public interface CustomerDao {
    public void addCustomer(Customer customer) throws SQLException;
    void UpdateCustomer(int cid,String name) throws SQLException;
    void deleteCustomer(int cid) throws SQLException;
    public Customer getcustomerbyid(int cid) throws SQLException;

}
