package com.tata.dao;

import com.tata.models.Category;
import helper.connections;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CategoryImpl implements CategoryDao{
    private Connection conn;
    private ResourceBundle resourceBundle;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement p1,du,uun,getcat;

    public CategoryImpl(){
        conn= connections.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");

    }
    @Override
    public void addCategory(Category category) {
        String addCategory = resourceBundle.getString("addc11");
        try {
            p1 = conn.prepareStatement(addCategory);
            p1.setInt(1, category.getCatid());
            p1.setString(2, category.getCname());

            p1.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public List<? extends Category> getAllCategories() throws SQLException {
            conn=connections.getConnection();
            String query=null;
            List<Category> categoryList=null;
            Category category=null;
            categoryList=new ArrayList<Category>();
            query=resourceBundle.getString("sp");
            statement=conn.createStatement();
            resultSet=statement.executeQuery(query);
            while(resultSet.next()){
                category=new Category();
                category.setCatid(resultSet.getInt(1));
                category.setCname(resultSet.getString(2));

                categoryList.add(category);
            }
            return categoryList;


    }



    @Override
    public Category getCategoryById(int catid) throws SQLException {
        Category category = new Category();
        String query = resourceBundle.getString("getc");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query+catid);
        while(resultSet.next())
        {
            category.setCatid(resultSet.getInt(1));
            category.setCname(resultSet.getString(2));
        }
        return category;
    }

    @Override
    public void updateCategory(int cid, String name) throws SQLException {
        String query = resourceBundle.getString("updatecat");
        uun = conn.prepareStatement(query);
        uun.setInt(2,cid);
        uun.setString(1,name);
        uun.executeUpdate();

    }

    @Override
    public void deleteCategory(int catid) throws SQLException {
        String query = resourceBundle.getString("deletecat");
        du = conn.prepareStatement(query);
        du.setInt(1, catid);
        du.executeUpdate();

    }


}
