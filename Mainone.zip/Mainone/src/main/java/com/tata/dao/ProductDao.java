package com.tata.dao;

import com.tata.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface ProductDao {
    void addProduct(Product product);
    void updateProductName(int p_id,String p_name) throws SQLException;
    void deleteProduct(int p_id) throws SQLException;
    List<Product> getAllProducts() throws SQLException;
    Product getProductById(int p_id) throws SQLException;
}