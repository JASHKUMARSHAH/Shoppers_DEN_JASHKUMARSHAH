package com.tata.dao;

import com.tata.models.Customer;
import com.tata.models.Order1;
import com.tata.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface OrderDao {
    void placeOrder(Customer customer, Order1 order) throws SQLException;
    void cancelOrder(int order_id) throws SQLException;
    //    void updateOrder(User user);
    List<Order1> viewAllOrder(Customer customer) throws SQLException;
    Order1 getOrderById(Customer customer, int orderId) throws SQLException;
    void confirmOrder(Customer customer, int order_id) throws SQLException;

}
