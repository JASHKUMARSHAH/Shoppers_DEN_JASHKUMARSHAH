package com.tata.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Admin {
    private  int a_id;
    private String a_name;
    private String a_pwd;
    //Customer customer;
}
