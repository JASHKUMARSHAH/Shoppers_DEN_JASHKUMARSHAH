package com.tata.models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Cart {
    private int ccid;
    private String pname;
    private int price;
    private int qty;
    //private int customer_id;
    //private Admin admin;
    private int c_id_ref;
    private int p_id_ref;
}
