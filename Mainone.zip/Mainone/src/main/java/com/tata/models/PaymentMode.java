package com.tata.models;

public enum PaymentMode {
    CARD,NETBANKING ,UPI
}
