package com.tata.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Customer {
    private String address;
    private String email;
    private String name;
    private int phn;
    private String pwd;
    private String sec_ans;
    private String sec_q;
    private int cid;
    private int ccid_ref;

}
