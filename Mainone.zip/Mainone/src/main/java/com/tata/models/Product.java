package com.tata.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    private LocalDate ld;

    private String pdes;
    private int pid;
    private String pname;
    private Long price;
    private int qnty;
    private Category category;
}
