package com.tata.utilities;

import com.tata.dao.*;
import com.tata.models.*;
import org.checkerframework.checker.units.qual.C;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Mainone1 {
//    public static void main(String[] args) throws SQLException {
//        CartDao cartDao =new CartImpl();
//        CustomerDao customerDao =new CustomerImpl();
//        Customer customer=customerDao.getcustomerbyid(44);
//        ProductDao productDao =new ProductImpl();
////        Product product=productDao.getProductById(2);
////        cartDao.addProduct(customer,product,10);
//        List<Cart> cartList=new ArrayList<Cart>();
//        cartList=cartDao.getAllProducts(customer);
//        for(Cart cart:cartList)
//        {
//            System.out.println(cart.getQty()+" "+cart.getPrice()+" "+cart.getCcid()+" "+cart.getC_id_ref()+" "+cart.getP_id_ref());
//        }
//    }
//private static final Scanner sc = new Scanner(System.in);
//public static void main(String[] args) throws SQLException {
//
//    ProductDao productDao=new ProductImpl();
//    Product product = createProduct();
//   productDao.addProduct(product);
//    CustomerDao customerDao=new CustomerImpl();
//    Customer customer =customerDao.getcustomerbyid(32);
//    Order1 order =createOrder();
//    OrderDao orderDao=new OrderDaoImpl();
//    orderDao.placeOrder(customer,order);


    private static final Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws SQLException {

        AdminDao adminDao = new AdminImpl();
        Admin admin=new Admin();
        //CategoryDao categoryDao =new CategoryImpl();
        CustomerDao customerDao = new CustomerImpl();
        Customer customer = null;
        Product product = new Product();
        ProductDao productDao = new ProductImpl();
        CategoryDao categoryDao = new CategoryImpl();
        OrderDao orderDao = new OrderDaoImpl();
        LoginDao loginDao = new LoginImpl();
        Order1 order = new Order1();
        Category category = new Category();
        LoginDao loginDao1 =new Loginimplcustomet();


        System.out.println();
        System.out.println("WELCOME");
        System.out.println("PRESS 1 FOR ADMIN AND 2 FOR CUSTOMER");
        int r = sc.nextInt();
        if (r == 1) {


            loop:
            while (true) {
                System.out.println("Welcome to Shoppers_Den");
                System.out.println("1 - Login");
                System.out.println("2 - Register");
                System.out.println("3 - Exit");
                String way = sc.nextLine();
                switch (way.toLowerCase()) {
                    case "login":
                        System.out.println("Enter your userId");
                        int id = Integer.parseInt(sc.nextLine());
                        System.out.println("Enter your password");
                        String pass = sc.nextLine();
                        if (loginDao.check(id, pass)) {
                            admin = adminDao.getAdminbyId(id);
                        } else {
                            System.out.println("Enter a valid id or pass");
                            continue loop;
                        }
                        break loop;
                    case "register":
                        admin= adminadd();
                        adminDao.addAdmin(admin);
                        System.out.println("You have been successfully registered with Login Id : " + admin.getA_id());
                        break loop;
                    case "exit":
                        System.exit(0);

                }
            }

            XYZ:
            while (true) {
                System.out.println("1 - Get all users ");
                System.out.println("2 - Delete User ");
                System.out.println("3 - Get a particular user ");
                System.out.println("4 - Add Product ");
                System.out.println("5 - Update Product Name ");
                System.out.println("6 - Delete Product ");
                System.out.println("7 - Get all Products ");
                System.out.println("8 - Get a particular product ");
                System.out.println("9 - Order History");
                System.out.println("10 - All Orders of User ");
                System.out.println("11 - Add Category ");
                System.out.println("12 - Delete Category ");
                System.out.println("13 - Update Category Name");
                System.out.println("14 - Get Category By ID ");
                System.out.println("15 - Get All Categories ");
                System.out.println("16 - View Profile ");
                System.out.println("17 - Update Profile ");
                System.out.println("18 - Log out and exit ");
                System.out.println("Enter your choice ");
                int c = Integer.parseInt(sc.nextLine());
                switch (c) {
                    case 1:
                        for (Customer customer1 : adminDao.getallcustomer())
                            System.out.println(customer1.getCid()
                                    + " " + customer1.getName()
                                    + " " + customer1.getEmail()
                                    + " " + customer1.getCcid_ref()
                                    + " " + customer1.getPhn()
                                    + " " + customer1.getAddress()
                                    + " " + customer1.getPwd()
                                    + " " + customer1.getSec_ans()
                                    + " " + customer1.getSec_q());
                        continue XYZ;
                    case 2:
                        System.out.println("Enter the user id to be deleted ");
                        int id = Integer.parseInt(sc.nextLine());
                        adminDao.deleteAdmin(id);
                        System.out.println("The user had been successfully deleted ");
                        continue XYZ;
                    case 3:
                        System.out.println("Enter the id of user ");
                        int id1 = Integer.parseInt(sc.nextLine());
                        Customer customer1 = customerDao.getcustomerbyid(id1);
                        System.out.println(customer1.getCid()
                                + " " + customer1.getName()
                                + " " + customer1.getEmail()
                                + " " + customer1.getCcid_ref()
                                + " " + customer1.getPhn()
                                + " " + customer1.getAddress()
                                + " " + customer1.getPwd()
                                + " " + customer1.getSec_ans()
                                + " " + customer1.getSec_q());

                        continue XYZ;
                    case 4:
                        product = createProduct();
                        productDao.addProduct(product);
                        System.out.println("The product has been successfullyy added ");
                        continue XYZ;
                    case 5:

                        System.out.println("Enter the product id ");
                        int pid = Integer.parseInt(sc.nextLine());
                        System.out.println("Enter the updated name ");
                        String uname = sc.nextLine();
                        productDao.updateProductName(pid, uname);
                        System.out.println("The product name has been updated ");
                        continue XYZ;
                    case 6:
                        System.out.println("Enter the product id");
                        int pid1 = Integer.parseInt(sc.nextLine());
                        productDao.deleteProduct(pid1);
                        System.out.println("The Product has been successfully deleted ");


                        continue XYZ;
                    case 7:
                        for (Product product1 : productDao.getAllProducts())
                            System.out.println(product1.getPid() + " " + product1.getPname()
                                    + " " + product1.getCategory().getCname()
                                    + " " + product1.getPrice()
                                    + " " + product1.getQnty() + " " + product1.getLd() + " " + product1.getPdes());
                        continue XYZ;
                    case 8:
                        System.out.println("Enter the product id ");
                        int pid2 = Integer.parseInt(sc.nextLine());
                        Product product2 = productDao.getProductById(pid2);
                        System.out.println(product2.getPid() + " " +
                                product2.getPname() + " " +
                                product2.getPrice() + " " +
                                product2.getQnty());

                        continue XYZ;
                    case 9:
                        System.out.println("Enter the user id ");
                        int uid1 = Integer.parseInt(sc.nextLine());
                        Customer user2 = customerDao.getcustomerbyid(uid1);
                        System.out.println("Enter your oder id ");
                        int od = Integer.parseInt(sc.nextLine());
                        System.out.println("Placed order for " + user2.getCid() + " is ");
                        order = orderDao.getOrderById(user2, od);
                        System.out.println(order.getOrderId() + " " + order.getTotalPayment() + " " + order.getStatus());
                        continue XYZ;
                    case 10:
                        System.out.println("Enter the user id ");
                        int uid2 = Integer.parseInt(sc.nextLine());
                        Customer user3 = customerDao.getcustomerbyid(uid2);
                        for (Order1 order3 : orderDao.viewAllOrder(user3)) {
                            System.out.println(order3.getOrderId() + " " + order3.getStatus() + " " + order3.getTotalPayment());
                        }
                        continue XYZ;
                    case 11:
                        category = createCategory();
                        categoryDao.addCategory(category);
                        System.out.println("New Category has been successfully added with id " + category.getCatid());
                        continue XYZ;
                    case 12:
                        System.out.println("Enter the category id to be deleted");
                        int cid = Integer.parseInt(sc.nextLine());
                        categoryDao.deleteCategory(cid);
                        System.out.println("The category with id " + cid + " has been deleted successfully");
                        continue XYZ;
                    case 13:
                        System.out.println("Enter the Category id ");
                        int cid2 = Integer.parseInt(sc.nextLine());
                        System.out.println("Enter the updated name ");
                        String ucn = sc.nextLine();
                        categoryDao.updateCategory(cid2, ucn);
                        System.out.println("Name changed successfully ");
                        continue XYZ;
                    case 14:
                        System.out.println("Enter the category id to get the details ");
                        int cid3 = Integer.parseInt(sc.nextLine());
                        Category category1 = categoryDao.getCategoryById(cid3);
                        System.out.println(category1.getCatid() + " " + category1.getCname());
                        continue XYZ;
                    case 15:
                        System.out.println("The List of all Categories is ");
                        for (Category category2 : categoryDao.getAllCategories()) {
                            System.out.println(category2.getCatid() + " " + category2.getCname());
                        }
                        continue XYZ;
                    case 16:
                        System.out.println("Your credentials are ");
                        System.out.println("Your user id is " + admin.getA_id()
                                + " " + "Your name is " + admin.getA_name());
                        continue XYZ;
                    case 17:
                        System.out.println("You are in update profile section ");
                        System.out.println("Enter your updated name");
                        String n = sc.nextLine();
                        customerDao.UpdateCustomer(customer.getCid(), n);
                        System.out.println("Your name has been updated successfully ");
                        continue XYZ;


                    case 18: System.exit(0);



                }
            }

        }
        else if(r==2){
            Customer customer1=null;

            //Login variable
            boolean correct = false;

            //Order
            Order1 order11=null;

            //UserDao
            CustomerDao customerDao1 = new CustomerImpl();
            //CartItems
            CartDao cartDao=new CartImpl();
            //Order
            OrderDao orderDao1=new OrderDaoImpl();
            //Products
            ProductDao productDao1=new ProductImpl();
            //login
            LoginDao login=new LoginImpl();

            System.out.println();
            loop:while(true) {
                System.out.println("Welcome to Shoppers_Den");
                System.out.println("1 - Login");
                System.out.println("2 - Register");
                System.out.println("3 - Exit");
                String way = sc.nextLine();
                switch (way.toLowerCase()) {
                    case "login":
                        System.out.println("Enter your userId");
                        int id = Integer.parseInt(sc.nextLine());
                        System.out.println("Enter your password");
                        String pass = sc.nextLine();
                        if (loginDao1.check(id, pass)) {
                            customer = customerDao.getcustomerbyid(id);
                            correct=true;
                        } else  {
                            System.out.println("Enter a valid id or pass");
                            continue loop;
                        }
                        break loop;
                    case "register":
                        customer = customeradd();
                        customerDao.addCustomer(customer);
                        System.out.println("You have been successfully registered with Login Id : " + customer.getCid());
                        correct=true;
                        break loop;
                    case "exit":
                        System.exit(0);
                }
            }
            if(correct) {
                XYZ:
                while (true) {
                    System.out.println("1 - View All Products ");
                    System.out.println("2 - Add to Cart ");
                    System.out.println("3 - Place Order ");
                    System.out.println("4 - Confirm Order");
                    System.out.println("5 - Update Profile ");
                    System.out.println("6 - View Profile ");
                    System.out.println("7 - Cancel Order");
                    System.out.println("8 - View Products in Cart");
                    System.out.println("9 - Order History");
                    System.out.println("10 - View Placed Order");
                    System.out.println("11 - Delete Profile");
                    System.out.println("12 - Logout and exit");
                    System.out.println("Enter your choice ");
                    int c = Integer.parseInt(sc.nextLine());
                    switch (c) {
                        case 1:
                            for (Product product1 : productDao.getAllProducts())
                                System.out.println(product1.getPid()
                                        + " " + product1.getPname() + " " + product1.getPdes());
                            continue XYZ;
                        case 2:
                            System.out.println("Enter product id");
                            int pid = Integer.parseInt(sc.nextLine());
                            product= productDao.getProductById(pid);
                            System.out.println("Enter quantity");
                            int q = Integer.parseInt(sc.nextLine());
                            cartDao.addProduct(customer, product, q);
                            System.out.println("Given product has been added successfully ");
                            continue XYZ;
                        case 3:
                            order = createOrder();
                            orderDao.placeOrder(customer, order);
                            System.out.println("Your order has been placed successfully ");
                            System.out.println("Your order is " + order.getOrderId());
                            continue XYZ;
                        case 4:
                            System.out.println("Enter your oder id ");
                            int oid = Integer.parseInt(sc.nextLine());
                            orderDao.confirmOrder(customer, oid);
                            System.out.println("Your order with order id " + oid + " has been successfully confirmed ");
                            continue XYZ;
                        case 5:
                            System.out.println("You are in update profile section ");
                            System.out.println("Enter your updated name");
                            String n = sc.nextLine();
                            customerDao.UpdateCustomer(customer.getCid(), n);
                            System.out.println("Your name has been updated successfully ");
                            continue XYZ;
                        case 6:
                            System.out.println("Your credentials are ");
                            System.out.println("Your user id is " + customer.getCid()
                                    + " " + "Your name is " + customer.getName()
                                    + " " + "Your phone number is " + customer.getPhn()
                                    + " " + "Your email is " + customer.getEmail());
                            System.out.println("Your orders are ");
                            for (Order1 order1 : orderDao.viewAllOrder(customer)) {
                                System.out.println("Your order id is " + order1.getOrderId()
                                        + " " + "Your total amount is " + order1.getTotalPayment()
                                        + " " + "Your mode is " + order1.getPaymentMode());
                            }
                            continue XYZ;
                        case 7:
                            System.out.println("Enter the id of the order you want to cancel ");
                            int id = Integer.parseInt(sc.nextLine());
                            orderDao.cancelOrder(id);
                            System.out.println("Your order has been canceled successfully ");
                            continue XYZ;
                        case 8:
                            System.out.println("Your cart items ");
                            for (Cart cartItems : cartDao.getAllProducts(customer)) {
                                System.out.println(cartItems.getPname()
                                        + " " + cartItems.getQty() + " " + cartItems.getPrice());
                            }
                            continue XYZ;
                        case 9:
                            System.out.println("Your order history is ");
                            for (Order1 order1 : orderDao.viewAllOrder(customer)) {
                                System.out.println("Your order id is " + order1.getOrderId()
                                        + " " + "Your total amount is " + order1.getTotalPayment()
                                        + " " + "Your mode is " + order1.getPaymentMode());
                            }
                            continue XYZ;
                        case 10:
                            System.out.println("Your placed order is ");
                            System.out.println("Enter your oder id ");
                            int od = Integer.parseInt(sc.nextLine());
                            order = orderDao.getOrderById(customer, od);
                            System.out.println(order.getOrderId() + " " + order.getTotalPayment() + " " + order.getStatus());
                            continue XYZ;
                        case 11:
                            customerDao.deleteCustomer(customer.getCid());
                            System.out.println("Your profile has been successfully deleted ");
                            System.exit(0);
                        case 12:
                            System.out.println("You have been successfully logged out ");
                            System.exit(0);

                        default:
                            break XYZ;
                    }
                }
            }

        }
        }
//
////
//
////
////
//
//
////        System.out.println("Enter the user id ");
////        int uid1=Integer.parseInt(sc.nextLine());
////        Customer user2=customerDao.getcustomerbyid(uid1);
////        System.out.println("Enter your oder id ");
//
////
//
//
////
////        customerDao.addCustomer(customeradd());
////        CartDao cartDao=new CartImpl();
////        Customer customer=new Customer();
////        AdminDao adminDao =new AdminImpl();
////        List<Customer> customerList=new ArrayList<>();
////
////        customerList=adminDao.getallcustomer();
////        for(Customer customer1 : adminDao.getallcustomer())
////        {
////            System.out.println(customer1);
////        }
////        System.out.println(customerList);
////        customer=customerDao.getcustomerbyid(30);
////
////        product=productDao.getProductById(2);
////        cartDao.addProduct(customer,product,9);
//////
//         productDao.addProduct(createProduct());
//        adminDao.addAdmin(adminadd());
//        AdminDao adminDao =new AdminImpl();
//        Customer customer= adminDao.getcustomerbyid(32);
//        System.out.println(customer);
//
//         for(int i=0;i<10;i++){
//        System.out.println(customeradd());
//        customerDao.addCustomer(customeradd());
//        CategoryDao categoryDao=new CategoryImpl();
//        categoryDao.addCategory(createCategory());

//
        private static Product createProduct ()
        {
            Product product = new Product();
            product.setLd(LocalDate.now());
            Category c = new Category();
            c.setCatid(5);
            product.setCategory(c);
            product.setPdes("abc");
            product.setPrice(100000L);
            product.setPid(new Random().nextInt(100));
            product.setPname("qwe");
            product.setQnty(1 + new Random().nextInt(10));
            return product;
        }
        public static Category createCategory ()
        {
            Category category = new Category();
            category.setCatid(new Random().nextInt(1000));
            category.setCname("abc");
            return category;
        }
    private static Admin adminadd(){
        Admin admin =new Admin();
        admin.setA_id(new Random().nextInt(100));
        admin.setA_name("Jashkumar");
        admin.setA_pwd("1234");
        return admin;
    }
    private static Cart addp(Customer customer,Product product,int qty){
        Cart cart =new Cart();
        cart.setCcid(new Random().nextInt(100));
        cart.setPname("Jashkumar");
        cart.setPrice(10000);
        cart.setQty(qty);
        cart.setC_id_ref(customer.getCid());
        cart.setP_id_ref(product.getPid());
        return cart;
    }
//
        private static Customer customeradd () {
            Customer customer = new Customer();
            customer.setAddress("xyz");
            customer.setCid(new Random().nextInt(100));
            customer.setEmail("abc@java");
            customer.setName("Jash");
            customer.setPhn(900 + new Random().nextInt(999));
            customer.setPwd("1234");
            customer.setSec_ans("JashTata");
            customer.setSec_q("Who");
            customer.setCcid_ref(new Random().nextInt(100));


            return customer;
        }

        public static Order1 createOrder () {
            Order1 o = new Order1();
            o.setOrderId(new Random().nextInt(10000));
            System.out.println("Enter payment mode");
            String mode = sc.nextLine();
            if (mode.equalsIgnoreCase("CARD")) {
                o.setPaymentMode(PaymentMode.CARD);
            } else if (mode.equalsIgnoreCase("NETBANKING")) {
                o.setPaymentMode(PaymentMode.NETBANKING);
            } else {
                o.setPaymentMode(PaymentMode.UPI);
            }
            o.setStatus(0);
            return o;
        }
//


}
